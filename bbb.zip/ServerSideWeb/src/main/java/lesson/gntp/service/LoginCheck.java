package lesson.gntp.service;

import java.sql.SQLException;

import lesson.gntp.dao.MemberDAO;
import lesson.gntp.vo.LoginVO;

/////////// JSP에서는 얘랑만 소통 ////////////

public class LoginCheck {
	// 메소드 작성
	// id, password를 파라메터로 받아서 boolean 값을 리턴하는 로직
	// 메소드명은 isMember
	public boolean isMember(String id, String pwd) {
		boolean flag = false;
//		if(id.equals("user01") && pwd.equals("2345")) {
//			flag=true;
//		}
		MemberDAO dao = new MemberDAO();
		try {
			flag = dao.selectMember(id, pwd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public LoginVO getMember(String id, String pwd) {
		LoginVO vo =null;
//		if(id.equals("user01") && pwd.equals("2345")) {
//			flag=true;
//		}
		MemberDAO dao = new MemberDAO();
		try {
			vo = dao.selectMemberInfo(id, pwd);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vo;
	}
}

	


	
